---
name: Bug Report
about: Report a bug in the URL Shortener
title: '[BUG] '
labels: 'bug'
assignees: ''
---

## 🐛 Bug Description
A clear and concise description of the bug.

## 🔄 Steps to Reproduce
1. Go to '...'
2. Click on '...'
3. Scroll down to '...'
4. See error

## ✅ Expected Behavior
A clear and concise description of what you expected to happen.

## ❌ Actual Behavior
A clear and concise description of what actually happened.

## 📸 Screenshots
If applicable, add screenshots to help explain the problem.

## 🖥️ Environment
- **OS**: [e.g. Windows 10, macOS 12, Ubuntu 20.04]
- **Java Version**: [e.g. Java 17]
- **Browser**: [e.g. Chrome 120, Firefox 119]
- **Application Version**: [e.g. 1.0.0]

## 📋 Console Logs
```
Paste any relevant console logs here
```

## 🧪 Additional Context
Add any other context about the problem here.

## 📋 Checklist
- [ ] I have searched existing issues to avoid duplicates
- [ ] I have provided clear steps to reproduce
- [ ] I have included relevant logs and error messages
- [ ] I have tested on different environments if applicable 