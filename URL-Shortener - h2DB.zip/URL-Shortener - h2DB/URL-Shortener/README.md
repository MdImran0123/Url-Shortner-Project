# URL Shortener

A simple URL shortening service built with plain Java, H2 Database, and modern web technologies.

## 📋 Requirements

### Core Requirements
- ✅ **No Frameworks**: Built with plain Java, HTML, CSS, and JavaScript
- ✅ **Anonymous URL Creation**: Users can create short URLs without registration
- ✅ **User Login System**: Additional features for authenticated users
- ✅ **Custom URL Feature**: Logged-in users can create custom short codes
- ✅ **H2 Database**: Uses H2 Database with JDBC for storage
- ✅ **SLF4J Logging**: Comprehensive logging throughout the application
- ✅ **Unit Testing**: JUnit 5 and Mockito for comprehensive testing

### Technical Stack
- **Backend**: Java 17, com.sun.net.httpserver.HttpServer
- **Database**: H2 Database with JDBC
- **Frontend**: Plain HTML, CSS, JavaScript (no frameworks)
- **Testing**: JUnit 5, Mockito
- **Logging**: SLF4J

## 🚀 Features

### Anonymous Features
- **URL Shortening**: Create short URLs from long URLs
- **URL Redirection**: Automatic redirection to original URLs
- **Access Tracking**: Count how many times URLs are accessed

### User Features (Requires Login)
- **Custom URLs**: Create custom short codes (e.g., `/mycompany` instead of `/abc123`)
- **User Dashboard**: View and manage your custom URLs
- **Authentication**: Secure login system

### Technical Features
- **Modern UI**: Clean, responsive web interface
- **Error Handling**: Comprehensive error handling and user feedback
- **Security**: Password hashing, input validation
- **Performance**: Efficient database queries and caching

## 🛠️ Setup Instructions

### Prerequisites
- Java 17 or higher
- Maven 3.6 or higher

### Quick Start
```bash
# Clone the repository
git clone <repository-url>
cd URL-Shortener

# Build the project
mvn clean compile

# Run tests
mvn test

# Start the application
mvn exec:java
```

### Manual Setup
```bash
# Download dependencies
mvn dependency:resolve

# Compile
mvn compile

# Run tests
mvn test

# Run application
mvn exec:java
```

## 🧪 Testing

### Running Tests
```bash
# Run all tests
mvn test

# Run specific test class
mvn test -Dtest=DatabaseManagerTest

# Run with detailed output
mvn test -Dtest=*Test -Dsurefire.useFile=false
```

### Test Coverage
- **DatabaseManagerTest**: Tests database operations and connection handling
- **UrlGeneratorTest**: Tests URL generation and validation utilities
- **UrlHandlerTest**: Tests HTTP request handling and URL shortening logic
- **Integration Tests**: End-to-end functionality testing

## 📁 Project Structure

```
URL-Shortener/
├── src/
│   ├── main/
│   │   ├── java/com/urlshortener/
│   │   │   ├── Main.java                    # Application entry point
│   │   │   ├── MainSimple.java              # Simple in-memory version
│   │   │   ├── database/
│   │   │   │   ├── DatabaseInterface.java   # Database operations interface
│   │   │   │   ├── DatabaseManager.java     # H2 database implementation
│   │   │   │   └── SimpleDatabaseManager.java # In-memory database
│   │   │   ├── server/
│   │   │   │   ├── HttpServer.java          # HTTP server implementation
│   │   │   │   └── handlers/                # HTTP request handlers
│   │   │   │       ├── AuthHandler.java     # Authentication handler
│   │   │   │       ├── RedirectHandler.java # URL redirection handler
│   │   │   │       ├── StaticHandler.java   # Static file handler
│   │   │   │       └── UrlHandler.java      # URL shortening handler
│   │   │   └── utils/
│   │   │       └── UrlGenerator.java        # URL generation utilities
│   │   ├── resources/
│   │   │   └── database/
│   │   │       └── schema.sql              # Database schema
│   │   └── web/                            # Web interface files
│   │       ├── index.html                  # Main application page
│   │       ├── css/
│   │       │   └── style.css              # Application styles
│   │       └── js/
│   │           ├── main.js                 # Main application JavaScript
│   │           └── auth.js                 # Authentication JavaScript
│   └── test/
│       └── java/com/urlshortener/
│           ├── database/
│           │   └── DatabaseManagerTest.java # Database tests
│           ├── server/handlers/
│           │   └── UrlHandlerTest.java      # HTTP handler tests
│           └── utils/
│               └── UrlGeneratorTest.java    # Utility tests
├── .github/                                # GitHub workflows and templates
│   ├── workflows/
│   │   └── ci.yml                         # CI/CD pipeline
│   ├── ISSUE_TEMPLATE/
│   │   ├── bug_report.md                  # Bug report template
│   │   └── feature_request.md             # Feature request template
│   └── pull_request_template.md           # PR template
├── pom.xml                                 # Maven configuration
├── run-simple.bat                         # Windows batch script for in-memory version
├── download-deps.ps1                      # PowerShell script to download dependencies
├── README.md                              # This file
├── PROJECT_SUMMARY.md                     # Project summary document
└── .gitignore                             # Git ignore rules
```

## 🔧 Configuration

### Database Configuration
The application uses H2 Database with the following configuration:
- **URL**: `jdbc:h2:./urlshortener;AUTO_SERVER=TRUE`
- **Username**: `sa`
- **Password**: (empty)
- **Auto-creation**: Tables are created automatically on first run

### Server Configuration
- **Port**: 3331 (configurable in Main.java)
- **Thread Pool**: 10 concurrent connections
- **Static Files**: Served from `/web` directory

## 🎯 API Endpoints

### Anonymous Endpoints
- `POST /shorten` - Create a short URL
- `GET /{shortCode}` - Redirect to original URL

### Authenticated Endpoints
- `POST /login` - User authentication
- `POST /custom` - Create custom short URL
- `GET /login` - Login page

### Static Files
- `GET /` - Main application page
- `GET /css/*` - CSS files
- `GET /js/*` - JavaScript files

## 🔐 Default Login
- **Username**: `admin`
- **Password**: `password`

## 🚀 Usage Examples

### Creating a Short URL
```bash
curl -X POST http://localhost:3331/shorten \
  -d "url=https://www.example.com/very-long-url"
```

### Creating a Custom URL (requires login)
```bash
curl -X POST http://localhost:3331/custom \
  -d "url=https://www.example.com&customCode=mycompany&username=admin"
```

### Accessing a Short URL
```bash
curl -L http://localhost:3331/abc123
```

## 🧪 Testing Strategy

### Unit Tests
- **Database Operations**: CRUD operations, connection handling
- **URL Generation**: Code generation, validation, uniqueness
- **HTTP Handlers**: Request processing, error handling
- **Authentication**: User login, password validation

### Integration Tests
- **End-to-End**: Complete URL shortening workflow
- **Database Integration**: Real database operations
- **HTTP Server**: Full request/response cycle

### Test Coverage Goals
- **Line Coverage**: >90%
- **Branch Coverage**: >85%
- **Function Coverage**: 100%

## 🔍 Monitoring and Logging

### Logging Configuration
- **Framework**: SLF4J with Simple Logger
- **Level**: INFO for production, DEBUG for development
- **Output**: Console and file logging

### Key Log Events
- Application startup/shutdown
- Database operations
- HTTP requests/responses
- Error conditions
- User authentication

## 🚀 Deployment

### Development
```bash
mvn clean compile exec:java
```

### Production
```bash
mvn clean package
java -jar target/url-shortener-1.0.0.jar
```

### Docker (Optional)
```dockerfile
FROM openjdk:17-jre-slim
COPY target/url-shortener-1.0.0.jar app.jar
EXPOSE 3331
CMD ["java", "-jar", "app.jar"]
```

## 🤝 Contributing

### Development Workflow
1. Create feature branch from main
2. Implement feature with tests
3. Run all tests: `mvn test`
4. Create pull request
5. Code review and merge

### Code Standards
- **Java**: Follow Google Java Style Guide
- **JavaScript**: Use ES6+ features, no frameworks
- **CSS**: Use modern CSS, responsive design
- **Testing**: Write tests for all new features


**Built with ❤️ using plain Java and modern web technologies**
