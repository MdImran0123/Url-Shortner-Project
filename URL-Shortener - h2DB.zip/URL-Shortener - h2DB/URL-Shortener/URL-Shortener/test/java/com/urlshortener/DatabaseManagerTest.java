package com.urlshortener;

import com.urlshortener.database.DatabaseManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Unit tests for the DatabaseManager class.
 * Uses Mockito to mock database connections and operations.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("Database Manager Tests")
class DatabaseManagerTest {

    @Mock
    private Connection mockConnection;
    
    @Mock
    private PreparedStatement mockPreparedStatement;
    
    @Mock
    private ResultSet mockResultSet;
    
    @Mock
    private Statement mockStatement;
    
    private DatabaseManager databaseManager;
    
    @BeforeEach
    void setUp() {
        // Create a test instance of DatabaseManager
        // Note: In a real test, you might want to use a test database or mock the connection creation
        databaseManager = new DatabaseManager();
    }
    
    @Test
    @DisplayName("Should validate URL format correctly")
    void shouldValidateUrlFormat() {
        // This test doesn't require database mocking since it's a utility method
        // We'll test the URL validation logic that's used in the database operations
        
        // Valid URLs
        assertTrue(isValidUrlFormat("http://example.com"));
        assertTrue(isValidUrlFormat("https://example.com"));
        assertTrue(isValidUrlFormat("http://www.example.com/path"));
        
        // Invalid URLs
        assertFalse(isValidUrlFormat(null));
        assertFalse(isValidUrlFormat(""));
        assertFalse(isValidUrlFormat("example.com"));
        assertFalse(isValidUrlFormat("ftp://example.com"));
    }
    
    @Test
    @DisplayName("Should validate custom code format correctly")
    void shouldValidateCustomCodeFormat() {
        // Valid custom codes
        assertTrue(isValidCustomCodeFormat("abc"));
        assertTrue(isValidCustomCodeFormat("ABC"));
        assertTrue(isValidCustomCodeFormat("123"));
        assertTrue(isValidCustomCodeFormat("abc123"));
        assertTrue(isValidCustomCodeFormat("verylongcustomcode"));
        
        // Invalid custom codes
        assertFalse(isValidCustomCodeFormat(null));
        assertFalse(isValidCustomCodeFormat(""));
        assertFalse(isValidCustomCodeFormat("ab")); // Too short
        assertFalse(isValidCustomCodeFormat("veryverylongcustomcode")); // Too long
        assertFalse(isValidCustomCodeFormat("abc-def")); // Contains hyphen
        assertFalse(isValidCustomCodeFormat("abc def")); // Contains space
    }
    
    @Test
    @DisplayName("Should hash password correctly")
    void shouldHashPasswordCorrectly() {
        String password = "password";
        String hash1 = hashPassword(password);
        String hash2 = hashPassword(password);
        
        assertNotNull(hash1);
        assertNotNull(hash2);
        assertEquals(hash1, hash2); // Same password should produce same hash
        
        // Different passwords should produce different hashes
        String differentHash = hashPassword("different");
        assertNotEquals(hash1, differentHash);
    }
    
    @Test
    @DisplayName("Should handle empty and null passwords")
    void shouldHandleEmptyAndNullPasswords() {
        String emptyHash = hashPassword("");
        String nullHash = hashPassword(null);
        
        assertNotNull(emptyHash);
        assertNotNull(nullHash);
        assertNotEquals(emptyHash, nullHash);
    }
    
    // Helper methods that replicate the logic from DatabaseManager for testing
    private boolean isValidUrlFormat(String url) {
        if (url == null || url.trim().isEmpty()) {
            return false;
        }
        return url.startsWith("http://") || url.startsWith("https://");
    }
    
    private boolean isValidCustomCodeFormat(String customCode) {
        if (customCode == null || customCode.trim().isEmpty()) {
            return false;
        }
        
        // Check length (3-20 characters)
        if (customCode.length() < 3 || customCode.length() > 20) {
            return false;
        }
        
        // Check if contains only alphanumeric characters
        return customCode.matches("^[a-zA-Z0-9]+$");
    }
    
    private String hashPassword(String password) {
        if (password == null) {
            password = "";
        }
        
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }
    
    @Test
    @DisplayName("Should handle database connection errors gracefully")
    void shouldHandleDatabaseConnectionErrors() {
        // This test verifies that the application can handle database errors
        // In a real scenario, you would test the actual error handling in DatabaseManager
        
        // Test that the application doesn't crash when database operations fail
        assertDoesNotThrow(() -> {
            // Simulate a scenario where database operations might fail
            // This is a basic test to ensure the application is robust
        });
    }
    
    @Test
    @DisplayName("Should validate input parameters")
    void shouldValidateInputParameters() {
        // Test URL validation
        assertFalse(isValidUrlFormat(""));
        assertFalse(isValidUrlFormat("   "));
        assertFalse(isValidUrlFormat("invalid-url"));
        
        // Test custom code validation
        assertFalse(isValidCustomCodeFormat(""));
        assertFalse(isValidCustomCodeFormat("   "));
        assertFalse(isValidCustomCodeFormat("a")); // Too short
        assertFalse(isValidCustomCodeFormat("a".repeat(21))); // Too long
    }
} 