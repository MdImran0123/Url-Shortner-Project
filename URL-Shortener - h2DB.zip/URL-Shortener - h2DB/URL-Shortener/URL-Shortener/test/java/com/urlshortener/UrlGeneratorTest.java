package com.urlshortener;

import com.urlshortener.utils.UrlGenerator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the UrlGenerator utility class.
 */
@DisplayName("URL Generator Tests")
class UrlGeneratorTest {

    @Test
    @DisplayName("Should generate 6-character short codes")
    void shouldGenerateSixCharacterCodes() {
        String shortCode = UrlGenerator.generateShortCode();
        
        assertNotNull(shortCode);
        assertEquals(6, shortCode.length());
    }

    @Test
    @DisplayName("Should generate alphanumeric codes")
    void shouldGenerateAlphanumericCodes() {
        String shortCode = UrlGenerator.generateShortCode();
        
        assertTrue(shortCode.matches("^[a-zA-Z0-9]+$"));
    }

    @Test
    @DisplayName("Should generate different codes on multiple calls")
    void shouldGenerateDifferentCodes() {
        String code1 = UrlGenerator.generateShortCode();
        String code2 = UrlGenerator.generateShortCode();
        String code3 = UrlGenerator.generateShortCode();
        
        assertNotEquals(code1, code2);
        assertNotEquals(code2, code3);
        assertNotEquals(code1, code3);
    }

    @Test
    @DisplayName("Should validate valid URLs")
    void shouldValidateValidUrls() {
        assertTrue(UrlGenerator.isValidUrl("http://example.com"));
        assertTrue(UrlGenerator.isValidUrl("https://example.com"));
        assertTrue(UrlGenerator.isValidUrl("http://www.example.com/path"));
        assertTrue(UrlGenerator.isValidUrl("https://subdomain.example.com:8080/path?param=value"));
    }

    @Test
    @DisplayName("Should reject invalid URLs")
    void shouldRejectInvalidUrls() {
        assertFalse(UrlGenerator.isValidUrl(null));
        assertFalse(UrlGenerator.isValidUrl(""));
        assertFalse(UrlGenerator.isValidUrl("   "));
        assertFalse(UrlGenerator.isValidUrl("example.com"));
        assertFalse(UrlGenerator.isValidUrl("ftp://example.com"));
        assertFalse(UrlGenerator.isValidUrl("not-a-url"));
    }

    @Test
    @DisplayName("Should validate valid custom codes")
    void shouldValidateValidCustomCodes() {
        assertTrue(UrlGenerator.isValidCustomCode("abc"));
        assertTrue(UrlGenerator.isValidCustomCode("ABC"));
        assertTrue(UrlGenerator.isValidCustomCode("123"));
        assertTrue(UrlGenerator.isValidCustomCode("abc123"));
        assertTrue(UrlGenerator.isValidCustomCode("my-custom-url"));
        assertTrue(UrlGenerator.isValidCustomCode("verylongcustomcode"));
    }

    @Test
    @DisplayName("Should reject invalid custom codes")
    void shouldRejectInvalidCustomCodes() {
        assertFalse(UrlGenerator.isValidCustomCode(null));
        assertFalse(UrlGenerator.isValidCustomCode(""));
        assertFalse(UrlGenerator.isValidCustomCode("   "));
        assertFalse(UrlGenerator.isValidCustomCode("ab")); // Too short
        assertFalse(UrlGenerator.isValidCustomCode("veryverylongcustomcode")); // Too long
        assertFalse(UrlGenerator.isValidCustomCode("abc-def")); // Contains hyphen
        assertFalse(UrlGenerator.isValidCustomCode("abc def")); // Contains space
        assertFalse(UrlGenerator.isValidCustomCode("abc@def")); // Contains special character
    }

    @Test
    @DisplayName("Should handle edge cases for custom codes")
    void shouldHandleEdgeCasesForCustomCodes() {
        // Exactly 3 characters (minimum)
        assertTrue(UrlGenerator.isValidCustomCode("abc"));
        
        // Exactly 20 characters (maximum)
        assertTrue(UrlGenerator.isValidCustomCode("abcdefghijklmnopqrst"));
        
        // Mixed case and numbers
        assertTrue(UrlGenerator.isValidCustomCode("AbC123"));
    }
} 