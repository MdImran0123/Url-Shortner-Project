Write-Host "Downloading dependencies..." -ForegroundColor Green

# Create lib directory
if (!(Test-Path "lib")) {
    New-Item -ItemType Directory -Path "lib"
}

# Set TLS version
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# Download dependencies
$dependencies = @(
    @{
        Url = "https://repo1.maven.org/maven2/mysql/mysql-connector-java/8.0.33/mysql-connector-java-8.0.33.jar"
        File = "lib\mysql-connector-java-8.0.33.jar"
    },
    @{
        Url = "https://repo1.maven.org/maven2/org/slf4j/slf4j-api/1.7.36/slf4j-api-1.7.36.jar"
        File = "lib\slf4j-api-1.7.36.jar"
    },
    @{
        Url = "https://repo1.maven.org/maven2/org/slf4j/slf4j-simple/1.7.36/slf4j-simple-1.7.36.jar"
        File = "lib\slf4j-simple-1.7.36.jar"
    }
)

foreach ($dep in $dependencies) {
    Write-Host "Downloading $($dep.File)..." -ForegroundColor Yellow
    try {
        Invoke-WebRequest -Uri $dep.Url -OutFile $dep.File
        Write-Host "Downloaded $($dep.File) successfully" -ForegroundColor Green
    } catch {
        Write-Host "Failed to download $($dep.File): $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host "Dependencies download completed!" -ForegroundColor Green
Read-Host "Press Enter to continue" 