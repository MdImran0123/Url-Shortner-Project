package com.urlshortener.database;

/**
 * Common interface for database operations.
 * This allows the application to work with different database implementations.
 */
public interface DatabaseInterface {
    /**
     * Initializes the database connection.
     */
    void initialize() throws Exception;

    /**
     * Saves a new URL with its short code to the database.
     */
    void saveUrl(String originalUrl, String shortCode) throws Exception;

    /**
     * Retrieves the original URL for a given short code.
     */
    String getOriginalUrl(String shortCode) throws Exception;

    /**
     * Checks if a short code already exists.
     */
    boolean shortCodeExists(String shortCode) throws Exception;

    /**
     * Authenticates a user with username and password.
     */
    boolean authenticateUser(String username, String password) throws Exception;

    /**
     * Saves a custom URL created by a logged-in user.
     */
    void saveCustomUrl(String username, String originalUrl, String customCode) throws Exception;

    /**
     * Gets the original URL for a custom short code.
     */
    String getCustomUrl(String customCode) throws Exception;

    /**
     * Checks if a custom code already exists.
     */
    boolean customCodeExists(String customCode) throws Exception;

    /**
     * Closes the database connection.
     */
    void close();
} 