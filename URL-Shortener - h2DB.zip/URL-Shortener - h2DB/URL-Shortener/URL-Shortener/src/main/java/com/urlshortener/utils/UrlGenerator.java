package com.urlshortener.utils;

import java.security.SecureRandom;

/**
 * Utility class for generating short URL codes.
 * Generates random 6-character alphanumeric codes.
 */
public class UrlGenerator {
    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private static final int CODE_LENGTH = 6;
    private static final SecureRandom random = new SecureRandom();
    
    /**
     * Generates a random short code for URL shortening.
     * 
     * @return A 6-character alphanumeric string
     */
    public static String generateShortCode() {
        StringBuilder code = new StringBuilder(CODE_LENGTH);
        
        for (int i = 0; i < CODE_LENGTH; i++) {
            int randomIndex = random.nextInt(CHARACTERS.length());
            code.append(CHARACTERS.charAt(randomIndex));
        }
        
        return code.toString();
    }
    
    /**
     * Validates if a custom short code is valid.
     * Custom codes must be 3-20 characters long and contain only alphanumeric characters.
     * 
     * @param customCode The custom code to validate
     * @return true if valid, false otherwise
     */
    public static boolean isValidCustomCode(String customCode) {
        if (customCode == null || customCode.trim().isEmpty()) {
            return false;
        }
        
        // Check length (3-20 characters)
        if (customCode.length() < 3 || customCode.length() > 20) {
            return false;
        }
        
        // Check if contains only alphanumeric characters
        return customCode.matches("^[a-zA-Z0-9]+$");
    }
    
    /**
     * Validates if a URL is properly formatted.
     * 
     * @param url The URL to validate
     * @return true if valid, false otherwise
     */
    public static boolean isValidUrl(String url) {
        if (url == null || url.trim().isEmpty()) {
            return false;
        }
        
        // Basic URL validation - check if it starts with http:// or https://
        return url.startsWith("http://") || url.startsWith("https://");
    }
} 