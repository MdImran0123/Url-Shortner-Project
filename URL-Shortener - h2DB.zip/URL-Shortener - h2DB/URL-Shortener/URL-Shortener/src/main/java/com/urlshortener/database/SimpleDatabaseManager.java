package com.urlshortener.database;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;

/**
 * Simple in-memory database manager for testing without MySQL.
 * This is a fallback option when MySQL is not available.
 */
public class SimpleDatabaseManager implements DatabaseInterface {
    private static final Logger logger = LoggerFactory.getLogger(SimpleDatabaseManager.class);
    
    private final Map<String, String> urls = new HashMap<>();
    private final Map<String, String> customUrls = new HashMap<>();
    private final Map<String, String> users = new HashMap<>();
    private final Map<String, Integer> accessCounts = new HashMap<>();

    public SimpleDatabaseManager() {
        // Initialize with default admin user
        users.put("admin", hashPassword("password"));
        logger.info("SimpleDatabaseManager initialized with in-memory storage");
    }

    /**
     * Initializes the database (no-op for in-memory).
     */
    public void initialize() {
        logger.info("SimpleDatabaseManager initialized successfully.");
    }

    /**
     * Saves a new URL with its short code.
     */
    public void saveUrl(String originalUrl, String shortCode) {
        urls.put(shortCode, originalUrl);
        accessCounts.put(shortCode, 0);
        logger.debug("Saved URL: {} -> {}", originalUrl, shortCode);
    }

    /**
     * Retrieves the original URL for a given short code.
     */
    public String getOriginalUrl(String shortCode) {
        String originalUrl = urls.get(shortCode);
        if (originalUrl != null) {
            accessCounts.put(shortCode, accessCounts.getOrDefault(shortCode, 0) + 1);
            logger.debug("Retrieved URL: {} -> {}", shortCode, originalUrl);
        }
        return originalUrl;
    }

    /**
     * Checks if a short code already exists.
     */
    public boolean shortCodeExists(String shortCode) {
        return urls.containsKey(shortCode);
    }

    /**
     * Authenticates a user with username and password.
     */
    public boolean authenticateUser(String username, String password) {
        String storedHash = users.get(username);
        return storedHash != null && storedHash.equals(hashPassword(password));
    }

    /**
     * Saves a custom URL created by a logged-in user.
     */
    public void saveCustomUrl(String username, String originalUrl, String customCode) {
        customUrls.put(customCode, originalUrl);
        accessCounts.put("custom_" + customCode, 0);
        logger.debug("Saved custom URL: {} -> {} for user {}", originalUrl, customCode, username);
    }

    /**
     * Gets the original URL for a custom short code.
     */
    public String getCustomUrl(String customCode) {
        String originalUrl = customUrls.get(customCode);
        if (originalUrl != null) {
            accessCounts.put("custom_" + customCode, accessCounts.getOrDefault("custom_" + customCode, 0) + 1);
            logger.debug("Retrieved custom URL: {} -> {}", customCode, originalUrl);
        }
        return originalUrl;
    }

    /**
     * Checks if a custom code already exists.
     */
    public boolean customCodeExists(String customCode) {
        return customUrls.containsKey(customCode);
    }

    /**
     * Simple password hashing using SHA-256.
     */
    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }

    /**
     * Closes the database (no-op for in-memory).
     */
    public void close() {
        logger.info("SimpleDatabaseManager closed");
    }
} 