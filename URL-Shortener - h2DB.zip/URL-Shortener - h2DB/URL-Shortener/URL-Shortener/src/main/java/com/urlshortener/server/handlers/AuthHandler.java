package com.urlshortener.server.handlers;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.urlshortener.database.DatabaseInterface;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * HTTP handler for authentication operations.
 * Handles user login requests.
 */
public class AuthHandler implements HttpHandler {
    private static final Logger logger = LoggerFactory.getLogger(AuthHandler.class);

    private final DatabaseInterface databaseManager;

    public AuthHandler(DatabaseInterface databaseManager) {
        this.databaseManager = databaseManager;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
    	
        String method = exchange.getRequestMethod();
        
        if ("OPTIONS".equalsIgnoreCase(method)) {
            exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
            exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
            exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");
            exchange.sendResponseHeaders(204, -1); // No body
            return;
        }

        logger.debug("Handling {} request to /login", method);

        try {
            if ("POST".equalsIgnoreCase(method)) {
                handleLogin(exchange);
            } else if ("GET".equalsIgnoreCase(method)) {
                serveLoginPage(exchange);
            } else {
                sendErrorResponse(exchange, 405, "Method Not Allowed");
            }
        } catch (Exception e) {
            logger.error("Error handling authentication request", e);
            sendErrorResponse(exchange, 500, "Internal Server Error");
        }
    }

    /**
     * Handles user login requests.
     */
    private void handleLogin(HttpExchange exchange) throws IOException {
        String contentType = exchange.getRequestHeaders().getFirst("Content-Type");
        String requestBody = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);

        Map<String, String> params;

        if (contentType != null && contentType.contains("application/json")) {
            params = parseJson(requestBody);
        } else {
            params = parseFormData(requestBody);
        }

        String username = params.get("username");
        String password = params.get("password");

        if (username == null || username.trim().isEmpty()) {
            sendErrorResponse(exchange, 400, "Username is required");
            return;
        }

        if (password == null || password.trim().isEmpty()) {
            sendErrorResponse(exchange, 400, "Password is required");
            return;
        }

        try {
            boolean authenticated = databaseManager.authenticateUser(username, password);

            if (authenticated) {
                String response = String.format(
                    "{\"success\": true, \"message\": \"Login successful\", \"username\": \"%s\"}",
                    username
                );
                sendJsonResponse(exchange, 200, response);
                logger.info("User logged in successfully: {}", username);
            } else {
                sendErrorResponse(exchange, 401, "Invalid username or password");
                logger.warn("Failed login attempt for user: {}", username);
            }

        } catch (Exception e) {
            logger.error("Database error during login", e);
            sendErrorResponse(exchange, 500, "Database error");
        }
    }

    /**
     * Serves the login page.
     */
    private void serveLoginPage(HttpExchange exchange) throws IOException {
        String html = """
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Login - URL Shortener</title>
                <link rel="stylesheet" href="/css/style.css">
                <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
                <style>
                    .login-container {
                        max-width: 400px;
                        margin: 50px auto;
                        padding: 40px;
                        background: white;
                        border-radius: 12px;
                        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                        border: 1px solid #e2e8f0;
                    }
                    
                    .login-header {
                        text-align: center;
                        margin-bottom: 30px;
                    }
                    
                    .login-header h1 {
                        color: #2d3748;
                        font-size: 2rem;
                        font-weight: 600;
                        margin-bottom: 8px;
                    }
                    
                    .login-header p {
                        color: #718096;
                        font-size: 0.95rem;
                    }
                    
                    .login-form .form-group {
                        margin-bottom: 20px;
                    }
                    
                    .login-form label {
                        display: block;
                        margin-bottom: 8px;
                        color: #4a5568;
                        font-weight: 500;
                        font-size: 0.9rem;
                    }
                    
                    .login-form input {
                        width: 100%;
                        padding: 12px 16px;
                        border: 2px solid #e2e8f0;
                        border-radius: 8px;
                        font-size: 1rem;
                        transition: border-color 0.2s ease;
                        box-sizing: border-box;
                    }
                    
                    .login-form input:focus {
                        outline: none;
                        border-color: #4299e1;
                        box-shadow: 0 0 0 3px rgba(66, 153, 225, 0.1);
                    }
                    
                    .login-form button {
                        width: 100%;
                        padding: 12px 24px;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        color: white;
                        border: none;
                        border-radius: 8px;
                        font-size: 1rem;
                        font-weight: 600;
                        cursor: pointer;
                        transition: all 0.2s ease;
                        margin-top: 10px;
                    }
                    
                    .login-form button:hover {
                        transform: translateY(-1px);
                        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
                    }
                    
                    .login-form button:disabled {
                        opacity: 0.6;
                        cursor: not-allowed;
                        transform: none;
                    }
                    
                    .back-link {
                        text-align: center;
                        margin-top: 20px;
                    }
                    
                    .back-link a {
                        color: #4299e1;
                        text-decoration: none;
                        font-weight: 500;
                        transition: color 0.2s ease;
                    }
                    
                    .back-link a:hover {
                        color: #3182ce;
                        text-decoration: underline;
                    }
                    
                    .message {
                        margin-top: 20px;
                        padding: 12px 16px;
                        border-radius: 8px;
                        font-size: 0.9rem;
                        display: none;
                    }
                    
                    .message.success {
                        background: #c6f6d5;
                        border: 1px solid #9ae6b4;
                        color: #22543d;
                    }
                    
                    .message.error {
                        background: #fed7d7;
                        border: 1px solid #feb2b2;
                        color: #c53030;
                    }
                    
                    .demo-credentials {
                        background: #f7fafc;
                        border: 1px solid #e2e8f0;
                        border-radius: 8px;
                        padding: 16px;
                        margin-top: 20px;
                        text-align: center;
                    }
                    
                    .demo-credentials h4 {
                        color: #4a5568;
                        margin: 0 0 8px 0;
                        font-size: 0.9rem;
                        font-weight: 600;
                    }
                    
                    .demo-credentials p {
                        color: #718096;
                        margin: 0;
                        font-size: 0.85rem;
                        font-family: 'Courier New', monospace;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="login-container">
                        <div class="login-header">
                            <h1>🔐 Login</h1>
                            <p>Access your custom URL features</p>
                        </div>
                        
                        <form id="loginForm" class="login-form">
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" id="username" name="username" placeholder="Enter your username" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" id="password" name="password" placeholder="Enter your password" required>
                            </div>
                            
                            <button type="submit">Sign In</button>
                        </form>
                        
                        <div class="demo-credentials">
                            <h4>Demo Credentials</h4>
                            <p>Username: admin</p>
                            <p>Password: password</p>
                        </div>
                        
                        <div class="back-link">
                            <a href="/">← Back to URL Shortener</a>
                        </div>
                        
                        <div id="message"></div>
                    </div>
                </div>
                
                <script src="/js/auth.js"></script>
            </body>
            </html>
            """;

        exchange.getResponseHeaders().add("Content-Type", "text/html; charset=UTF-8");
        byte[] responseBytes = html.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(200, responseBytes.length);

        try (OutputStream os = exchange.getResponseBody()) {
            os.write(responseBytes);
        }
    }

    /**
     * Parses URL-encoded form data.
     */
    private Map<String, String> parseFormData(String formData) {
        Map<String, String> params = new HashMap<>();
        if (formData == null || formData.trim().isEmpty()) {
            return params;
        }

        String[] pairs = formData.split("&");
        for (String pair : pairs) {
        	String[] keyValue = pair.split("=", 2);
            if (keyValue.length == 2) {
                try {
                    String key = URLDecoder.decode(keyValue[0], StandardCharsets.UTF_8.name());
                    String value = URLDecoder.decode(keyValue[1], StandardCharsets.UTF_8.name());
                    params.put(key, value);
                } catch (Exception e) {
                    logger.warn("Error parsing form data: {}", pair);
                }
            }
        }
        return params;
    }

    /**
     * Parses simple JSON string into a map (manual parsing without libraries).
     */
    private Map<String, String> parseJson(String json) {
        Map<String, String> params = new HashMap<>();
        json = json.trim();
        json = json.replaceAll("[{}\"]", ""); // remove {, }, and "
        String[] pairs = json.split(",");
        for (String pair : pairs) {
            String[] keyValue = pair.split(":");
            if (keyValue.length == 2) {
                String key = keyValue[0].trim();
                String value = keyValue[1].trim();
                params.put(key, value);
            }
        }
        return params;
    }

    /**
     * Sends a JSON response.
     */
    private void sendJsonResponse(HttpExchange exchange, int statusCode, String json) throws IOException {
        exchange.getResponseHeaders().add("Content-Type", "application/json");
        exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");

        byte[] responseBytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(statusCode, responseBytes.length);

        try (OutputStream os = exchange.getResponseBody()) {
            os.write(responseBytes);
        }
    }

    /**
     * Sends an error response.
     */
    private void sendErrorResponse(HttpExchange exchange, int statusCode, String message) throws IOException {
        String errorJson = String.format("{\"success\": false, \"error\": \"%s\"}", message);
        sendJsonResponse(exchange, statusCode, errorJson);
    }
}
