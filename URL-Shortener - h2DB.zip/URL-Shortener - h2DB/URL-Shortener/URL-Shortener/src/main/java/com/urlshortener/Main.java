package com.urlshortener;

import com.urlshortener.database.DatabaseManager;
import com.urlshortener.server.HttpServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Main class for the URL Shortener application.
 * This class initializes the database and starts the HTTP server.
 */
public class Main {
    private static final Logger logger = LoggerFactory.getLogger(Main.class);
    private static final int DEFAULT_PORT = 3331;

    public static void main(String[] args) {
        try {
            logger.info("Starting URL Shortener application...");
            
            // Initialize database
            DatabaseManager databaseManager = new DatabaseManager();
            databaseManager.initialize();
            logger.info("Database initialized successfully");
            
            // Start HTTP server
            HttpServer server = new HttpServer(DEFAULT_PORT, databaseManager);
            server.start();
            
            logger.info("URL Shortener server started on port {}", DEFAULT_PORT);
            logger.info("Access the application at: http://localhost:{}", DEFAULT_PORT);
            
            // Keep the application running
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                logger.info("Shutting down URL Shortener...");
                server.stop();
                databaseManager.close();
                logger.info("URL Shortener stopped successfully");
            }));
            
        } catch (Exception e) {
            logger.error("Failed to start URL Shortener application", e);
            System.exit(1);
        }
    }
} 