package com.urlshortener.server.handlers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.urlshortener.database.DatabaseInterface;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.OutputStream;

public class RedirectHandler implements HttpHandler {
    private static final Logger logger = LoggerFactory.getLogger(RedirectHandler.class);
    private DatabaseInterface dbManager;
    private StaticHandler staticHandler;

    public RedirectHandler(DatabaseInterface dbManager) {
        this.dbManager = dbManager;
        this.staticHandler = new StaticHandler();
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String path = exchange.getRequestURI().getPath();
        
        logger.debug("RedirectHandler: Processing path: {}", path);
        
        // If it's the root path or has a file extension, serve static files
        if ("/".equals(path) || path.contains(".")) {
            logger.debug("RedirectHandler: Serving static file for path: {}", path);
            staticHandler.handle(exchange);
            return;
        }
        
        // Otherwise, treat it as a short URL
        String shortCode = path.substring(1); // remove leading '/'
        logger.debug("RedirectHandler: Looking up short code: {}", shortCode);

        String originalUrl = null;

        try {
            // First check in custom URLs
            logger.debug("RedirectHandler: Checking custom URLs for code: {}", shortCode);
            originalUrl = dbManager.getCustomUrl(shortCode);
            
            if (originalUrl != null) {
                logger.info("RedirectHandler: Found custom URL - {} -> {}", shortCode, originalUrl);
            } else {
                // Then check in normal URLs
                logger.debug("RedirectHandler: Checking normal URLs for code: {}", shortCode);
                originalUrl = dbManager.getOriginalUrl(shortCode);
                
                if (originalUrl != null) {
                    logger.info("RedirectHandler: Found normal URL - {} -> {}", shortCode, originalUrl);
                }
            }
        } catch (Exception e) {
            logger.error("RedirectHandler: Error looking up URL for code: {}", shortCode, e);
        }

        if (originalUrl != null) {
            // Set redirect headers
            logger.info("RedirectHandler: Redirecting {} -> {}", shortCode, originalUrl);
            exchange.getResponseHeaders().add("Location", originalUrl);
            exchange.sendResponseHeaders(302, -1);
            
            // Close the response body to complete the redirect
            try (OutputStream os = exchange.getResponseBody()) {
                // No body content for redirects
            }
        } else {
            // If not found, serve the main page
            logger.debug("RedirectHandler: No URL found for code: {}, serving main page", shortCode);
            staticHandler.handle(exchange);
        }
    }
}
