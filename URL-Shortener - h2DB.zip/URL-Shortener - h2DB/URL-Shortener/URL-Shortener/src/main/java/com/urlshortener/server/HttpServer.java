package com.urlshortener.server;

import com.urlshortener.database.DatabaseInterface;
import com.urlshortener.server.handlers.AuthHandler;
import com.urlshortener.server.handlers.RedirectHandler;
import com.urlshortener.server.handlers.StaticHandler;
import com.urlshortener.server.handlers.UrlHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.concurrent.Executors;

/**
 * HTTP server for the URL Shortener application.
 * Uses Java's built-in HttpServer to handle HTTP requests.
 */
public class HttpServer {
    private static final Logger logger = LoggerFactory.getLogger(HttpServer.class);
    
    private final com.sun.net.httpserver.HttpServer server;
    private final DatabaseInterface databaseManager;
    private final int port;
    
    /**
     * Creates a new HTTP server instance.
     * 
     * @param port The port to listen on
     * @param databaseManager The database manager instance
     * @throws IOException If the server cannot be created
     */
    public HttpServer(int port, DatabaseInterface databaseManager) throws IOException {
        this.port = port;
        this.databaseManager = databaseManager;
        
        // Create the HTTP server
        server = com.sun.net.httpserver.HttpServer.create(new InetSocketAddress(port), 0);
        
        // Set up thread pool
        server.setExecutor(Executors.newFixedThreadPool(10));
        
        // Register handlers
        registerHandlers();
        
        logger.info("HTTP server created on port {}", port);
    }
    
    /**
     * Registers all HTTP handlers for different endpoints.
     */ 
    private void registerHandlers() {
        // URL shortening endpoints (register these first)
        server.createContext("/shorten", new UrlHandler(databaseManager));
        server.createContext("/custom", new UrlHandler(databaseManager));
        server.createContext("/login", new AuthHandler(databaseManager));
        
        // Redirect handler for short URLs (register before static handler)
        server.createContext("/", new RedirectHandler(databaseManager));
        
        logger.debug("HTTP handlers registered");
    }

//    private void registerHandlers1() {
//        server.createContext("/shorten", new UrlHandler(databaseManager));
//        server.createContext("/custom", new UrlHandler(databaseManager));
//        server.createContext("/login", new AuthHandler(databaseManager));
//
//        // StaticHandler only for static files like .css, .js, .html
//        server.createContext("/css", new StaticHandler());
//        server.createContext("/js", new StaticHandler());
//
//        // Add this line for all short URLs like /abc123
//        server.createContext("/", new RedirectHandler(databaseManager)); 
//    }
    
    
    
    /**
     * Starts the HTTP server.
     */
    public void start() {
        server.start();
        logger.info("HTTP server started successfully on port {}", port);
    }
    
    /**
     * Stops the HTTP server.
     */
    public void stop() {
        server.stop(0);
        logger.info("HTTP server stopped");
    }
    
    /**
     * Gets the port the server is running on.
     * 
     * @return The server port
     */
    public int getPort() {
        return port;
    }
} 