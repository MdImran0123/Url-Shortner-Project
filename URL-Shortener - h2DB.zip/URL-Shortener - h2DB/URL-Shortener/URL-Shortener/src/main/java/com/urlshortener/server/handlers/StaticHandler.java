package com.urlshortener.server.handlers;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;

/**
 * HTTP handler for serving static files (HTML, CSS, JS).
 * Serves files from the web directory in the classpath.
 */
public class StaticHandler implements HttpHandler {
    private static final Logger logger = LoggerFactory.getLogger(StaticHandler.class);
    
    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String path = exchange.getRequestURI().getPath();
        
        logger.debug("Serving static file: {}", path);
        
        // Default to index.html for root path
        if ("/".equals(path)) {
            path = "/index.html";
        }
        
        // Remove leading slash for resource lookup
        String resourcePath = "web" + path;
        
        try {
            // Try to load the resource from classpath
            URL resourceUrl = getClass().getClassLoader().getResource(resourcePath);
            
            if (resourceUrl != null) {
                serveFile(exchange, resourceUrl, path);
            } else {
                // If not found, try to serve index.html for SPA routing
                if (!path.contains(".") || path.endsWith(".html")) {
                    // Try to serve index.html for any HTML-like request
                    URL indexUrl = getClass().getClassLoader().getResource("web/index.html");
                    if (indexUrl != null) {
                        serveFile(exchange, indexUrl, "/index.html");
                    } else {
                        sendErrorResponse(exchange, 404, "File not found: " + path);
                    }
                } else {
                    sendErrorResponse(exchange, 404, "File not found: " + path);
                }
            }
        } catch (Exception e) {
            logger.error("Error serving static file: {}", path, e);
            sendErrorResponse(exchange, 500, "Internal Server Error");
        }
    }
    
    /**
     * Serves a file from the given URL.
     */
    private void serveFile(HttpExchange exchange, URL resourceUrl, String path) throws IOException {
        String contentType = getContentType(path);
        
        try (InputStream inputStream = resourceUrl.openStream();
             OutputStream outputStream = exchange.getResponseBody()) {
            
            // Read the file content
            byte[] content = inputStream.readAllBytes();
            
            // Set response headers
            exchange.getResponseHeaders().add("Content-Type", contentType);
            exchange.getResponseHeaders().add("Cache-Control", "public, max-age=3600");
            
            // Send response
            exchange.sendResponseHeaders(200, content.length);
            outputStream.write(content);
            
            logger.debug("Served file: {} ({} bytes)", path, content.length);
        }
    }
    
    /**
     * Determines the content type based on file extension.
     */
    private String getContentType(String path) {
        if (path.endsWith(".html")) {
            return "text/html; charset=UTF-8";
        } else if (path.endsWith(".css")) {
            return "text/css; charset=UTF-8";
        } else if (path.endsWith(".js")) {
            return "application/javascript; charset=UTF-8";
        } else if (path.endsWith(".png")) {
            return "image/png";
        } else if (path.endsWith(".jpg") || path.endsWith(".jpeg")) {
            return "image/jpeg";
        } else if (path.endsWith(".gif")) {
            return "image/gif";
        } else if (path.endsWith(".ico")) {
            return "image/x-icon";
        } else {
            return "application/octet-stream";
        }
    }
    
    /**
     * Sends an error response.
     */
    private void sendErrorResponse(HttpExchange exchange, int statusCode, String message) throws IOException {
        String errorHtml = String.format("""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Error %d</title>
                <style>
                    body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
                    .error { color: #d32f2f; }
                </style>
            </head>
            <body>
                <h1 class="error">Error %d</h1>
                <p>%s</p>
                <p><a href="/">Go back to URL Shortener</a></p>
            </body>
            </html>
            """, statusCode, statusCode, message);
        
        exchange.getResponseHeaders().add("Content-Type", "text/html; charset=UTF-8");
        byte[] responseBytes = errorHtml.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(statusCode, responseBytes.length);
        
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(responseBytes);
        }
    }
} 