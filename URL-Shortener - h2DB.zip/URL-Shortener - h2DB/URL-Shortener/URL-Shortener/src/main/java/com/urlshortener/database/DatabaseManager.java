package com.urlshortener.database;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.nio.charset.StandardCharsets;
import java.sql.*;

/**
 * Manages database connections and operations for the URL Shortener application.
 * Uses H2 database with JDBC.
 */
public class DatabaseManager implements DatabaseInterface {
    private static final Logger logger = LoggerFactory.getLogger(DatabaseManager.class);

    // H2 Database configuration
    private static final String DB_URL = "jdbc:h2:./urlshortener;AUTO_SERVER=TRUE";
    private static final String DB_USER = "sa";
    private static final String DB_PASSWORD = "";

    private Connection connection;

    /**
     * Initializes the database connection and creates tables if they don't exist.
     */
    public void initialize() throws SQLException {
        logger.info("Connecting to H2 database...");
        
        try {
            // Load H2 driver
            Class.forName("org.h2.Driver");
            
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            logger.info("Connected to H2 database successfully.");
            
            // Create tables if they don't exist
            createTablesIfNotExist();
            
        } catch (ClassNotFoundException e) {
            logger.error("H2 database driver not found", e);
            throw new SQLException("H2 database driver not found", e);
        } catch (SQLException e) {
            logger.error("Failed to connect to database", e);
            throw e;
        }
    }

    /**
     * Creates the database tables if they don't exist.
     */
    private void createTablesIfNotExist() throws SQLException {
        logger.info("Creating database tables if they don't exist...");
        
        // Create urls table
        String createUrlsTable = """
            CREATE TABLE IF NOT EXISTS urls (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                original_url VARCHAR(2048) NOT NULL,
                short_code VARCHAR(10) NOT NULL UNIQUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                access_count BIGINT DEFAULT 0
            )
            """;
        
        // Create users table
        String createUsersTable = """
            CREATE TABLE IF NOT EXISTS users (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) NOT NULL UNIQUE,
                password_hash VARCHAR(255) NOT NULL,
                email VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_login TIMESTAMP
            )
            """;
        
        // Create custom_urls table
        String createCustomUrlsTable = """
            CREATE TABLE IF NOT EXISTS custom_urls (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT NOT NULL,
                original_url VARCHAR(2048) NOT NULL,
                custom_code VARCHAR(20) NOT NULL UNIQUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                access_count BIGINT DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
            """;
        
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(createUrlsTable);
            stmt.execute(createUsersTable);
            stmt.execute(createCustomUrlsTable);
            
            // Insert default admin user if not exists
            insertDefaultAdminUser();
            
            logger.info("Database tables created successfully.");
        } catch (SQLException e) {
            logger.error("Failed to create database tables", e);
            throw e;
        }
    }

    /**
     * Inserts a default admin user for testing.
     */
    private void insertDefaultAdminUser() throws SQLException {
        String checkUserSql = "SELECT COUNT(*) FROM users WHERE username = 'admin'";
        String insertUserSql = "INSERT INTO users (username, password_hash, email) VALUES (?, ?, ?)";
        
        try (PreparedStatement checkStmt = connection.prepareStatement(checkUserSql);
             PreparedStatement insertStmt = connection.prepareStatement(insertUserSql)) {
            
            // Check if admin user exists
            try (ResultSet rs = checkStmt.executeQuery()) {
                if (rs.next() && rs.getInt(1) == 0) {
                    // Insert default admin user (password: 'password')
                    insertStmt.setString(1, "admin");
                    insertStmt.setString(2, "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8");
                    insertStmt.setString(3, "admin@urlshortener.com");
                    insertStmt.executeUpdate();
                    logger.info("Default admin user created (username: admin, password: password)");
                }
            }
        }
    }

    /**
     * Saves a new URL with its short code to the database.
     */
    public void saveUrl(String originalUrl, String shortCode) throws SQLException {
        String sql = "INSERT INTO urls (original_url, short_code) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, originalUrl);
            stmt.setString(2, shortCode);
            stmt.executeUpdate();
            logger.debug("Saved URL: {} -> {}", originalUrl, shortCode);
        }
    }

    /**
     * Retrieves the original URL for a given short code.
     */
    public String getOriginalUrl(String shortCode) throws SQLException {
        String sql = "SELECT original_url FROM urls WHERE short_code = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, shortCode);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String originalUrl = rs.getString("original_url");
                    incrementAccessCount(shortCode);
                    logger.debug("Retrieved URL: {} -> {}", shortCode, originalUrl);
                    return originalUrl;
                }
            }
        }
        return null;
    }

    /**
     * Increments the access count for a URL.
     */
    private void incrementAccessCount(String shortCode) throws SQLException {
        String sql = "UPDATE urls SET access_count = access_count + 1 WHERE short_code = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, shortCode);
            stmt.executeUpdate();
        }
    }

    /**
     * Checks if a short code already exists.
     */
    public boolean shortCodeExists(String shortCode) throws SQLException {
        String sql = "SELECT COUNT(*) FROM urls WHERE short_code = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, shortCode);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    /**
     * Authenticates a user with username and password.
     */
    public boolean authenticateUser(String username, String password) throws SQLException {
        String sql = "SELECT password_hash FROM users WHERE username = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, username);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String storedHash = rs.getString("password_hash");
                    return storedHash.equals(hashPassword(password));
                }
            }
        }
        return false;
    }

    /**
     * Saves a custom URL created by a logged-in user.
     */
    public void saveCustomUrl(String username, String originalUrl, String customCode) throws SQLException {
        Long userId = getUserId(username);
        if (userId == null) {
            throw new SQLException("User not found: " + username);
        }

        String sql = "INSERT INTO custom_urls (user_id, original_url, custom_code) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setLong(1, userId);
            stmt.setString(2, originalUrl);
            stmt.setString(3, customCode);
            stmt.executeUpdate();
            logger.debug("Saved custom URL: {} -> {} for user {}", originalUrl, customCode, username);
        }
    }

    /**
     * Gets the original URL for a custom short code.
     */
    public String getCustomUrl(String customCode) throws SQLException {
        String sql = "SELECT original_url FROM custom_urls WHERE custom_code = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, customCode);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String originalUrl = rs.getString("original_url");
                    incrementCustomUrlAccessCount(customCode);
                    logger.debug("Retrieved custom URL: {} -> {}", customCode, originalUrl);
                    return originalUrl;
                }
            }
        }
        return null;
    }

    /**
     * Checks if a custom code already exists.
     */
    public boolean customCodeExists(String customCode) throws SQLException {
        String sql = "SELECT COUNT(*) FROM custom_urls WHERE custom_code = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, customCode);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    /**
     * Gets user ID by username.
     */
    private Long getUserId(String username) throws SQLException {
        String sql = "SELECT id FROM users WHERE username = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, username);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getLong("id");
                }
            }
        }
        return null;
    }

    /**
     * Increments the access count for a custom URL.
     */
    private void incrementCustomUrlAccessCount(String customCode) throws SQLException {
        String sql = "UPDATE custom_urls SET access_count = access_count + 1 WHERE custom_code = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, customCode);
            stmt.executeUpdate();
        }
    }

    /**
     * Simple password hashing using SHA-256.
     */
    private String hashPassword(String password) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            throw new RuntimeException("Error hashing password", e);
        }
    }

    /**
     * Closes the database connection.
     */
    public void close() {
        if (connection != null) {
            try {
                connection.close();
                logger.info("Database connection closed");
            } catch (SQLException e) {
                logger.error("Error closing database connection", e);
            }
        }
    }
}
