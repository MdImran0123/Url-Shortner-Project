package com.urlshortener.server.handlers;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.urlshortener.database.DatabaseInterface;
import com.urlshortener.utils.UrlGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * HTTP handler for URL shortening operations.
 * Handles creating short URLs and redirecting to original URLs.
 */
public class UrlHandler implements HttpHandler {
    private static final Logger logger = LoggerFactory.getLogger(UrlHandler.class);
    
    private final DatabaseInterface databaseManager;
    
    public UrlHandler(DatabaseInterface databaseManager) {
        this.databaseManager = databaseManager;
    }
    
    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod();
        String path = exchange.getRequestURI().getPath();
        
        logger.debug("Handling {} request to {}", method, path);
        
        try {
            if ("POST".equals(method)) {
                if ("/shorten".equals(path)) {
                    handleShortenUrl(exchange);
                } else if ("/custom".equals(path)) {
                    handleCustomUrl(exchange);
                } else {
                    sendErrorResponse(exchange, 404, "Not Found");
                }
            } else {
                sendErrorResponse(exchange, 405, "Method Not Allowed");
            }
        } catch (Exception e) {
            logger.error("Error handling request", e);
            sendErrorResponse(exchange, 500, "Internal Server Error");
        }
    }
    
    /**
     * Handles URL shortening requests.
     */
    private void handleShortenUrl(HttpExchange exchange) throws IOException {
        // Read request body
        String requestBody = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        Map<String, String> params = parseFormData(requestBody);
        
        String originalUrl = params.get("url");
        
        if (originalUrl == null || originalUrl.trim().isEmpty()) {
            sendErrorResponse(exchange, 400, "URL is required");
            return;
        }
        
        if (!UrlGenerator.isValidUrl(originalUrl)) {
            sendErrorResponse(exchange, 400, "Invalid URL format. Must start with http:// or https://");
            return;
        }
        
        try {
            // Generate a unique short code
            String shortCode;
            do {
                shortCode = UrlGenerator.generateShortCode();
            } while (databaseManager.shortCodeExists(shortCode));
            
            // Save to database
            databaseManager.saveUrl(originalUrl, shortCode);
            
            // Create response
           // String shortUrl = "http://localhost:8080/" + shortCode;
            String shortUrl = "http://localhost:" + exchange.getLocalAddress().getPort() + "/" + shortCode;
            String response = String.format("{\"success\": true, \"shortUrl\": \"%s\", \"originalUrl\": \"%s\"}", 
                                          shortUrl, originalUrl);
            
            sendJsonResponse(exchange, 200, response);
            logger.info("Created short URL: {} -> {}", shortCode, originalUrl);
            
        } catch (Exception e) {
            logger.error("Database error while shortening URL", e);
            sendErrorResponse(exchange, 500, "Database error");
        }
    }
    
    /**
     * Handles custom URL creation requests.
     */
    private void handleCustomUrl(HttpExchange exchange) throws IOException {
        // Read request body
        String requestBody = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        Map<String, String> params = parseFormData(requestBody);
        
        String originalUrl = params.get("url");
        String customCode = params.get("customCode");
        String username = params.get("username");
        
        logger.debug("Custom URL request - URL: {}, Code: {}, User: {}", originalUrl, customCode, username);
        
        if (originalUrl == null || originalUrl.trim().isEmpty()) {
            sendErrorResponse(exchange, 400, "URL is required");
            return;
        }
        
        if (customCode == null || customCode.trim().isEmpty()) {
            sendErrorResponse(exchange, 400, "Custom code is required");
            return;
        }
        
        if (username == null || username.trim().isEmpty()) {
            sendErrorResponse(exchange, 400, "Username is required");
            return;
        }
        
        if (!UrlGenerator.isValidUrl(originalUrl)) {
            sendErrorResponse(exchange, 400, "Invalid URL format. Must start with http:// or https://");
            return;
        }
        
        if (!UrlGenerator.isValidCustomCode(customCode)) {
            sendErrorResponse(exchange, 400, "Invalid custom code. Must be 3-20 alphanumeric characters");
            return;
        }
        
        try {
            // Check if custom code already exists
            if (databaseManager.customCodeExists(customCode) || databaseManager.shortCodeExists(customCode)) {
                logger.warn("Custom code already exists: {}", customCode);
                sendErrorResponse(exchange, 409, "Custom code already exists");
                return;
            }
            
            // Save custom URL
            databaseManager.saveCustomUrl(username, originalUrl, customCode);
            logger.info("Successfully saved custom URL: {} -> {} for user {}", customCode, originalUrl, username);
            
            // Create response
            String shortUrl = "http://localhost:" + exchange.getLocalAddress().getPort() + "/" + customCode;
            String response = String.format("{\"success\": true, \"shortUrl\": \"%s\", \"originalUrl\": \"%s\"}", 
                                          shortUrl, originalUrl);
            
            sendJsonResponse(exchange, 200, response);
            logger.info("Created custom URL: {} -> {} for user {}", customCode, originalUrl, username);
            
        } catch (Exception e) {
            logger.error("Database error while creating custom URL", e);
            sendErrorResponse(exchange, 500, "Database error");
        }
    }
    
    /**
     * Parses form data from request body.
     */
    private Map<String, String> parseFormData(String formData) {
        Map<String, String> params = new HashMap<>();
        if (formData == null || formData.trim().isEmpty()) {
            return params;
        }
        
        String[] pairs = formData.split("&");
        for (String pair : pairs) {
            String[] keyValue = pair.split("=");
            if (keyValue.length == 2) {
                try {
                    String key = URLDecoder.decode(keyValue[0], StandardCharsets.UTF_8.name());
                    String value = URLDecoder.decode(keyValue[1], StandardCharsets.UTF_8.name());
                    params.put(key, value);
                } catch (Exception e) {
                    logger.warn("Error parsing form data: {}", pair);
                }
            }
        }
        return params;
    }
    
    /**
     * Sends a JSON response.
     */
    private void sendJsonResponse(HttpExchange exchange, int statusCode, String json) throws IOException {
        exchange.getResponseHeaders().add("Content-Type", "application/json");
        exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");
        
        byte[] responseBytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(statusCode, responseBytes.length);
        
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(responseBytes);
        }
    }
    
    /**
     * Sends an error response.
     */
    private void sendErrorResponse(HttpExchange exchange, int statusCode, String message) throws IOException {
        String errorJson = String.format("{\"success\": false, \"error\": \"%s\"}", message);
        sendJsonResponse(exchange, statusCode, errorJson);
    }
} 