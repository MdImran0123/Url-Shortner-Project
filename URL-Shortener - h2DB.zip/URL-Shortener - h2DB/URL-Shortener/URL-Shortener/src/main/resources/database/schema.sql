-- URL Shortener Database Schema
-- This file contains the SQL statements to create the necessary tables

-- Table to store original URLs and their generated short codes
CREATE TABLE IF NOT EXISTS urls (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    original_url VARCHAR(2048) NOT NULL,
    short_code VARCHAR(10) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    access_count BIGINT DEFAULT 0,
    INDEX idx_short_code (short_code),
    INDEX idx_original_url (original_url)
);

-- Table to store user accounts for authentication
CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    INDEX idx_username (username)
);

-- Table to store custom short URLs created by logged-in users
CREATE TABLE IF NOT EXISTS custom_urls (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    original_url VARCHAR(2048) NOT NULL,
    custom_code VARCHAR(20) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    access_count BIGINT DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_custom_code (custom_code),
    INDEX idx_user_id (user_id)
);

-- Insert some sample data for testing
INSERT INTO users (username, password_hash, email) VALUES 
('admin', '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', 'admin@urlshortener.com')
ON DUPLICATE KEY UPDATE username = username;

-- Note: The password hash above is for 'password' (SHA-256)
-- In a real application, you would use proper password hashing with salt 