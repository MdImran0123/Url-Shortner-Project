// Main JavaScript for URL Shortener
document.addEventListener('DOMContentLoaded', function () {
    const shortenForm = document.getElementById('shortenForm');
    const customForm = document.getElementById('customForm');
    const loginPrompt = document.getElementById('loginPrompt');
    const createCustomBtn = document.getElementById('createCustomBtn');
    const copyBtn = document.getElementById('copyBtn');

    // ✅ Check session-based login
    const currentUser = sessionStorage.getItem('currentUser');
    if (currentUser) {
        showCustomForm();
    }

    // Handle URL shortening form submission
    shortenForm.addEventListener('submit', async function (e) {
        e.preventDefault();

        const urlInput = document.getElementById('url');
        const url = urlInput.value.trim();

        if (!url) {
            showError('Please enter a URL');
            return;
        }

        if (!isValidUrl(url)) {
            showError('Please enter a valid URL starting with http:// or https://');
            return;
        }

        await shortenUrl(url);
    });

    // Handle custom URL creation
    createCustomBtn.addEventListener('click', async function () {
        const customUrl = document.getElementById('customUrl').value.trim();
        const customCode = document.getElementById('customCode').value.trim();

        if (!customUrl || !customCode) {
            showError('Please fill in all fields');
            return;
        }

        if (!isValidUrl(customUrl)) {
            showError('Please enter a valid URL starting with http:// or https://');
            return;
        }

        if (!isValidCustomCode(customCode)) {
            showError('Custom code must be 3-20 alphanumeric characters');
            return;
        }

        await createCustomUrl(customUrl, customCode);
    });

    // Copy button
    copyBtn.addEventListener('click', function () {
        const shortUrlInput = document.getElementById('shortUrl');
        shortUrlInput.select();
        shortUrlInput.setSelectionRange(0, 99999);

        try {
            document.execCommand('copy');
            showSuccess('URL copied to clipboard!');
        } catch (err) {
            navigator.clipboard.writeText(shortUrlInput.value).then(function () {
                showSuccess('URL copied to clipboard!');
            }).catch(function () {
                showError('Failed to copy URL');
            });
        }
    });

    async function shortenUrl(originalUrl) {
        const submitBtn = shortenForm.querySelector('button[type="submit"]');
        const btnText = submitBtn.querySelector('.btn-text');
        const btnLoading = submitBtn.querySelector('.btn-loading');

        submitBtn.classList.add('loading');
        submitBtn.disabled = true;
        hideError();
        hideResult();

        try {
            const formData = new URLSearchParams();
            formData.append('url', originalUrl);

            const response = await fetch('/shorten', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: formData
            });

            const data = await response.json();

            if (data.success) {
                showResult(data.shortUrl, originalUrl);
            } else {
                showError(data.error || 'Failed to shorten URL');
            }
        } catch (error) {
            console.error('Error shortening URL:', error);
            showError('Network error. Please try again.');
        } finally {
            submitBtn.classList.remove('loading');
            submitBtn.disabled = false;
        }
    }

    async function createCustomUrl(originalUrl, customCode) {
        const currentUser = sessionStorage.getItem('currentUser'); // ✅ sessionStorage

        if (!currentUser) {
            showError('Please login to create custom URLs');
            return;
        }

        createCustomBtn.disabled = true;
        createCustomBtn.textContent = 'Creating...';
        hideError();

        try {
            const formData = new URLSearchParams();
            formData.append('url', originalUrl);
            formData.append('customCode', customCode);
            formData.append('username', currentUser);

            const response = await fetch('/custom', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: formData
            });

            const data = await response.json();

            if (data.success) {
                showResult(data.shortUrl, originalUrl);
                document.getElementById('customUrl').value = '';
                document.getElementById('customCode').value = '';
            } else {
                showError(data.error || 'Failed to create custom URL');
            }
        } catch (error) {
            console.error('Error creating custom URL:', error);
            showError('Network error. Please try again.');
        } finally {
            createCustomBtn.disabled = false;
            createCustomBtn.textContent = 'Create Custom URL';
        }
    }

    function showCustomForm() {
        customForm.style.display = 'block';
        loginPrompt.style.display = 'none';
    }

    function showResult(shortUrl, originalUrl) {
        const resultDiv = document.getElementById('result');
        const shortUrlInput = document.getElementById('shortUrl');
        const originalUrlSpan = document.getElementById('originalUrl');

        shortUrlInput.value = shortUrl;
        originalUrlSpan.textContent = originalUrl;

        resultDiv.style.display = 'block';
        resultDiv.classList.add('success');

        resultDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    function hideResult() {
        document.getElementById('result').style.display = 'none';
    }

    function showError(message) {
        const errorDiv = document.getElementById('error');
        errorDiv.textContent = message;
        errorDiv.style.display = 'block';

        errorDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    function hideError() {
        document.getElementById('error').style.display = 'none';
    }

    function showSuccess(message) {
        const successDiv = document.createElement('div');
        successDiv.className = 'success-message';
        successDiv.textContent = message;
        successDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #48bb78;
            color: white;
            padding: 12px 20px;
            border-radius: 6px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 1000;
            animation: slideIn 0.3s ease;
        `;

        document.body.appendChild(successDiv);

        setTimeout(() => {
            successDiv.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                if (successDiv.parentNode) {
                    successDiv.parentNode.removeChild(successDiv);
                }
            }, 300);
        }, 3000);
    }

    function isValidUrl(url) {
        return url.startsWith('http://') || url.startsWith('https://');
    }

    function isValidCustomCode(code) {
        return /^[a-zA-Z0-9]{3,20}$/.test(code);
    }
});

// CSS animation for toast message
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to   { transform: translateX(0); opacity: 1; }
    }

    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to   { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);
