// Authentication JavaScript for URL Shortener
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const messageDiv = document.getElementById('message');
    
    // Handle login form submission
    loginForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value.trim();
        
        if (!username || !password) {
            showMessage('Please fill in all fields', 'error');
            return;
        }
        
        await login(username, password);
    });

    /**
     * Attempts to log in the user
     */
    async function login(username, password) {
        const submitBtn = loginForm.querySelector('button[type="submit"]');
        
        // Show loading state
        submitBtn.disabled = true;
        submitBtn.textContent = 'Logging in...';
        hideMessage();
        
        try {
            const formData = new URLSearchParams();
            formData.append('username', username);
            formData.append('password', password);
            
            const response = await fetch('/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                // ✅ Store user info in sessionStorage instead of localStorage
                sessionStorage.setItem('currentUser', username);
                
                showMessage('Login successful! Redirecting...', 'success');
                
                setTimeout(() => {
                    window.location.href = '/';
                }, 1500);
            } else {
                showMessage(data.error || 'Login failed', 'error');
            }
        } catch (error) {
            console.error('Login error:', error);
            showMessage('Network error. Please try again.', 'error');
        } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Login';
        }
    }

    /**
     * Shows a message to the user
     */
    function showMessage(message, type) {
        messageDiv.textContent = message;
        messageDiv.className = `message ${type}`;
        messageDiv.style.display = 'block';
        
        if (type === 'success') {
            messageDiv.style.cssText = `
                display: block;
                padding: 12px 16px;
                margin-top: 15px;
                background: #c6f6d5;
                border: 1px solid #9ae6b4;
                border-radius: 6px;
                color: #22543d;
                font-size: 0.9rem;
            `;
        } else if (type === 'error') {
            messageDiv.style.cssText = `
                display: block;
                padding: 12px 16px;
                margin-top: 15px;
                background: #fed7d7;
                border: 1px solid #feb2b2;
                border-radius: 6px;
                color: #c53030;
                font-size: 0.9rem;
            `;
        }
    }

    function hideMessage() {
        messageDiv.style.display = 'none';
    }

    // ✅ Use sessionStorage instead of localStorage
    window.logout = function() {
        sessionStorage.removeItem('currentUser');
        window.location.href = '/';
    };

    window.isLoggedIn = function() {
        return sessionStorage.getItem('currentUser') !== null;
    };

    window.getCurrentUser = function() {
        return sessionStorage.getItem('currentUser');
    };
});
