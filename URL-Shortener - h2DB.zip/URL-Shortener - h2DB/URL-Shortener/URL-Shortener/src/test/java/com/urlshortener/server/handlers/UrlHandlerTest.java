package com.urlshortener.server.handlers;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.urlshortener.database.DatabaseInterface;
import com.urlshortener.utils.UrlGenerator;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class UrlHandlerTest {
    
    private static final Logger logger = LoggerFactory.getLogger(UrlHandlerTest.class);
    
    @Mock
    private DatabaseInterface databaseManager;
    
    private UrlHandler urlHandler;
    
    @BeforeEach
    void setUp() {
        urlHandler = new UrlHandler(databaseManager);
    }
    
    @Test
    @Order(1)
    @DisplayName("Should handle POST /shorten request successfully")
    void testHandleShortenUrl() throws Exception {
        // Arrange
        HttpExchange exchange = createMockHttpExchange("POST", "/shorten", "url=https://www.example.com");
        
        when(databaseManager.shortCodeExists(anyString())).thenReturn(false);
        doNothing().when(databaseManager).saveUrl(anyString(), anyString());
        
        // Act
        urlHandler.handle(exchange);
        
        // Assert
        verify(databaseManager).saveUrl("https://www.example.com", anyString());
        logger.info("POST /shorten test passed");
    }
    
    @Test
    @Order(2)
    @DisplayName("Should handle POST /custom request successfully")
    void testHandleCustomUrl() throws Exception {
        // Arrange
        HttpExchange exchange = createMockHttpExchange("POST", "/custom", "url=https://www.example.com&customCode=mycustom&username=admin");
        
        when(databaseManager.authenticateUser("admin", "password")).thenReturn(true);
        when(databaseManager.customCodeExists("mycustom")).thenReturn(false);
        doNothing().when(databaseManager).saveCustomUrl(anyString(), anyString(), anyString());
        
        // Act
        urlHandler.handle(exchange);
        
        // Assert
        verify(databaseManager).saveCustomUrl("admin", "https://www.example.com", "mycustom");
        logger.info("POST /custom test passed");
    }
    
    @Test
    @Order(3)
    @DisplayName("Should handle GET request for URL redirection")
    void testHandleUrlRedirect() throws Exception {
        // Arrange
        HttpExchange exchange = createMockHttpExchange("GET", "/abc123", "");
        
        when(databaseManager.getOriginalUrl("abc123")).thenReturn("https://www.example.com");
        
        // Act
        urlHandler.handle(exchange);
        
        // Assert
        verify(databaseManager).getOriginalUrl("abc123");
        assertEquals("https://www.example.com", exchange.getResponseHeaders().getFirst("Location"));
        assertEquals(302, exchange.getResponseCode());
        logger.info("GET URL redirect test passed");
    }
    
    @Test
    @Order(4)
    @DisplayName("Should return 400 for invalid URL")
    void testHandleInvalidUrl() throws Exception {
        // Arrange
        HttpExchange exchange = createMockHttpExchange("POST", "/shorten", "url=invalid-url");
        
        // Act
        urlHandler.handle(exchange);
        
        // Assert
        assertEquals(400, exchange.getResponseCode());
        logger.info("Invalid URL test passed");
    }
    
    @Test
    @Order(5)
    @DisplayName("Should return 400 for missing URL")
    void testHandleMissingUrl() throws Exception {
        // Arrange
        HttpExchange exchange = createMockHttpExchange("POST", "/shorten", "other=value");
        
        // Act
        urlHandler.handle(exchange);
        
        // Assert
        assertEquals(400, exchange.getResponseCode());
        logger.info("Missing URL test passed");
    }
    
    @Test
    @Order(6)
    @DisplayName("Should return 405 for unsupported method")
    void testHandleUnsupportedMethod() throws Exception {
        // Arrange
        HttpExchange exchange = createMockHttpExchange("PUT", "/shorten", "");
        
        // Act
        urlHandler.handle(exchange);
        
        // Assert
        assertEquals(405, exchange.getResponseCode());
        logger.info("Unsupported method test passed");
    }
    
    @Test
    @Order(7)
    @DisplayName("Should handle database exceptions gracefully")
    void testHandleDatabaseException() throws Exception {
        // Arrange
        HttpExchange exchange = createMockHttpExchange("POST", "/shorten", "url=https://www.example.com");
        
        when(databaseManager.shortCodeExists(anyString())).thenThrow(new RuntimeException("Database error"));
        
        // Act
        urlHandler.handle(exchange);
        
        // Assert
        assertEquals(500, exchange.getResponseCode());
        logger.info("Database exception handling test passed");
    }
    
    @Test
    @Order(8)
    @DisplayName("Should handle custom URL with authentication failure")
    void testHandleCustomUrlAuthenticationFailure() throws Exception {
        // Arrange
        HttpExchange exchange = createMockHttpExchange("POST", "/custom", "url=https://www.example.com&customCode=mycustom&username=admin");
        
        when(databaseManager.authenticateUser("admin", "password")).thenReturn(false);
        
        // Act
        urlHandler.handle(exchange);
        
        // Assert
        assertEquals(401, exchange.getResponseCode());
        logger.info("Custom URL authentication failure test passed");
    }
    
    @Test
    @Order(9)
    @DisplayName("Should handle custom code already exists")
    void testHandleCustomCodeExists() throws Exception {
        // Arrange
        HttpExchange exchange = createMockHttpExchange("POST", "/custom", "url=https://www.example.com&customCode=mycustom&username=admin");
        
        when(databaseManager.authenticateUser("admin", "password")).thenReturn(true);
        when(databaseManager.customCodeExists("mycustom")).thenReturn(true);
        
        // Act
        urlHandler.handle(exchange);
        
        // Assert
        assertEquals(409, exchange.getResponseCode());
        logger.info("Custom code exists test passed");
    }
    
    @Test
    @Order(10)
    @DisplayName("Should validate URL format correctly")
    void testUrlValidation() {
        // Valid URLs
        assertTrue(UrlGenerator.isValidUrl("http://www.example.com"));
        assertTrue(UrlGenerator.isValidUrl("https://www.example.com"));
        
        // Invalid URLs
        assertFalse(UrlGenerator.isValidUrl("www.example.com"));
        assertFalse(UrlGenerator.isValidUrl("ftp://www.example.com"));
        assertFalse(UrlGenerator.isValidUrl(""));
        assertFalse(UrlGenerator.isValidUrl(null));
        
        logger.info("URL validation test passed");
    }
    
    /**
     * Creates a mock HttpExchange for testing
     */
    private HttpExchange createMockHttpExchange(String method, String path, String requestBody) throws IOException {
        HttpExchange exchange = mock(HttpExchange.class);
        Headers headers = new Headers();
        ByteArrayInputStream inputStream = new ByteArrayInputStream(requestBody.getBytes());
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        
        when(exchange.getRequestMethod()).thenReturn(method);
        when(exchange.getRequestURI()).thenReturn(URI.create("http://localhost:3331" + path));
        when(exchange.getRequestHeaders()).thenReturn(headers);
        when(exchange.getRequestBody()).thenReturn(inputStream);
        when(exchange.getResponseBody()).thenReturn(outputStream);
        when(exchange.getLocalAddress()).thenReturn(new InetSocketAddress("localhost", 3331));
        
        // Mock response methods
        doAnswer(invocation -> {
            int statusCode = invocation.getArgument(0);
            long responseLength = invocation.getArgument(1);
            return null;
        }).when(exchange).sendResponseHeaders(anyInt(), anyLong());
        
        return exchange;
    }
} 