package com.urlshortener.database;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class DatabaseManagerTest {
    
    private static final Logger logger = LoggerFactory.getLogger(DatabaseManagerTest.class);
    private DatabaseManager databaseManager;
    
    @BeforeEach
    void setUp() {
        databaseManager = new DatabaseManager();
    }
    
    @Test
    @Order(1)
    @DisplayName("Should initialize database successfully")
    void testInitialize() {
        assertDoesNotThrow(() -> {
            databaseManager.initialize();
            logger.info("Database initialization test passed");
        });
    }
    
    @Test
    @Order(2)
    @DisplayName("Should save URL successfully")
    void testSaveUrl() {
        assertDoesNotThrow(() -> {
            databaseManager.initialize();
            databaseManager.saveUrl("https://www.example.com", "abc123");
            logger.info("URL save test passed");
        });
    }
    
    @Test
    @Order(3)
    @DisplayName("Should retrieve original URL successfully")
    void testGetOriginalUrl() {
        assertDoesNotThrow(() -> {
            databaseManager.initialize();
            String originalUrl = "https://www.example.com";
            String shortCode = "abc123";
            
            databaseManager.saveUrl(originalUrl, shortCode);
            String retrievedUrl = databaseManager.getOriginalUrl(shortCode);
            
            assertEquals(originalUrl, retrievedUrl);
            logger.info("URL retrieval test passed");
        });
    }
    
    @Test
    @Order(4)
    @DisplayName("Should check if short code exists")
    void testShortCodeExists() {
        assertDoesNotThrow(() -> {
            databaseManager.initialize();
            String shortCode = "abc123";
            
            // Initially should not exist
            assertFalse(databaseManager.shortCodeExists(shortCode));
            
            // After saving, should exist
            databaseManager.saveUrl("https://www.example.com", shortCode);
            assertTrue(databaseManager.shortCodeExists(shortCode));
            
            logger.info("Short code existence test passed");
        });
    }
    
    @Test
    @Order(5)
    @DisplayName("Should authenticate user successfully")
    void testAuthenticateUser() {
        assertDoesNotThrow(() -> {
            databaseManager.initialize();
            
            // Test with default admin user
            assertTrue(databaseManager.authenticateUser("admin", "password"));
            assertFalse(databaseManager.authenticateUser("admin", "wrongpassword"));
            assertFalse(databaseManager.authenticateUser("nonexistent", "password"));
            
            logger.info("User authentication test passed");
        });
    }
    
    @Test
    @Order(6)
    @DisplayName("Should save custom URL successfully")
    void testSaveCustomUrl() {
        assertDoesNotThrow(() -> {
            databaseManager.initialize();
            
            String originalUrl = "https://www.example.com";
            String customCode = "mycustom";
            
            databaseManager.saveCustomUrl("admin", originalUrl, customCode);
            
            // Verify it was saved
            assertTrue(databaseManager.customCodeExists(customCode));
            
            logger.info("Custom URL save test passed");
        });
    }
    
    @Test
    @Order(7)
    @DisplayName("Should retrieve custom URL successfully")
    void testGetCustomUrl() {
        assertDoesNotThrow(() -> {
            databaseManager.initialize();
            
            String originalUrl = "https://www.example.com";
            String customCode = "mycustom2";
            
            databaseManager.saveCustomUrl("admin", originalUrl, customCode);
            String retrievedUrl = databaseManager.getCustomUrl(customCode);
            
            assertEquals(originalUrl, retrievedUrl);
            logger.info("Custom URL retrieval test passed");
        });
    }
    
    @Test
    @Order(8)
    @DisplayName("Should check if custom code exists")
    void testCustomCodeExists() {
        assertDoesNotThrow(() -> {
            databaseManager.initialize();
            String customCode = "mycustom3";
            
            // Initially should not exist
            assertFalse(databaseManager.customCodeExists(customCode));
            
            // After saving, should exist
            databaseManager.saveCustomUrl("admin", "https://www.example.com", customCode);
            assertTrue(databaseManager.customCodeExists(customCode));
            
            logger.info("Custom code existence test passed");
        });
    }
    
    @Test
    @Order(9)
    @DisplayName("Should handle non-existent URLs gracefully")
    void testGetNonExistentUrl() {
        assertDoesNotThrow(() -> {
            databaseManager.initialize();
            
            // Test non-existent short code
            assertNull(databaseManager.getOriginalUrl("nonexistent"));
            assertNull(databaseManager.getCustomUrl("nonexistent"));
            
            logger.info("Non-existent URL handling test passed");
        });
    }
    
    @Test
    @Order(10)
    @DisplayName("Should close database connection successfully")
    void testClose() {
        assertDoesNotThrow(() -> {
            databaseManager.initialize();
            databaseManager.close();
            logger.info("Database close test passed");
        });
    }
    
    @Test
    @DisplayName("Should handle SQL exceptions gracefully")
    void testSqlExceptionHandling() {
        // This test verifies that SQL exceptions are properly handled
        // by testing with invalid data
        assertDoesNotThrow(() -> {
            databaseManager.initialize();
            
            // Try to save with null values (should throw exception)
            assertThrows(SQLException.class, () -> {
                databaseManager.saveUrl(null, "test");
            });
            
            logger.info("SQL exception handling test passed");
        });
    }
    
    @AfterEach
    void tearDown() {
        if (databaseManager != null) {
            databaseManager.close();
        }
    }
} 