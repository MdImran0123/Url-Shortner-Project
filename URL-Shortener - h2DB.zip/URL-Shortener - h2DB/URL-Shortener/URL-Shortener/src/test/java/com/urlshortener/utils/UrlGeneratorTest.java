package com.urlshortener.utils;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class UrlGeneratorTest {
    
    private static final Logger logger = LoggerFactory.getLogger(UrlGeneratorTest.class);
    
    @Test
    @Order(1)
    @DisplayName("Should generate short code with correct length")
    void testGenerateShortCodeLength() {
        String shortCode = UrlGenerator.generateShortCode();
        
        assertEquals(6, shortCode.length());
        logger.info("Short code length test passed: {}", shortCode);
    }
    
    @Test
    @Order(2)
    @DisplayName("Should generate alphanumeric short codes only")
    void testGenerateShortCodeAlphanumeric() {
        String shortCode = UrlGenerator.generateShortCode();
        
        assertTrue(shortCode.matches("^[a-zA-Z0-9]+$"));
        logger.info("Short code alphanumeric test passed: {}", shortCode);
    }
    
    @Test
    @Order(3)
    @DisplayName("Should generate unique short codes")
    void testGenerateShortCodeUniqueness() {
        Set<String> generatedCodes = new HashSet<>();
        int iterations = 1000;
        
        for (int i = 0; i < iterations; i++) {
            String code = UrlGenerator.generateShortCode();
            assertTrue(generatedCodes.add(code), "Duplicate code generated: " + code);
        }
        
        assertEquals(iterations, generatedCodes.size());
        logger.info("Short code uniqueness test passed for {} iterations", iterations);
    }
    
    @Test
    @Order(4)
    @DisplayName("Should validate custom codes correctly")
    void testIsValidCustomCode() {
        // Valid custom codes
        assertTrue(UrlGenerator.isValidCustomCode("abc"));
        assertTrue(UrlGenerator.isValidCustomCode("abc123"));
        assertTrue(UrlGenerator.isValidCustomCode("ABC123"));
        assertTrue(UrlGenerator.isValidCustomCode("mycustomurl"));
        assertTrue(UrlGenerator.isValidCustomCode("my-custom-url"));
        
        // Invalid custom codes
        assertFalse(UrlGenerator.isValidCustomCode(null));
        assertFalse(UrlGenerator.isValidCustomCode(""));
        assertFalse(UrlGenerator.isValidCustomCode("ab")); // too short
        assertFalse(UrlGenerator.isValidCustomCode("a".repeat(21))); // too long
        assertFalse(UrlGenerator.isValidCustomCode("abc def")); // contains space
        assertFalse(UrlGenerator.isValidCustomCode("abc-def")); // contains hyphen
        assertFalse(UrlGenerator.isValidCustomCode("abc_def")); // contains underscore
        
        logger.info("Custom code validation test passed");
    }
    
    @Test
    @Order(5)
    @DisplayName("Should validate URLs correctly")
    void testIsValidUrl() {
        // Valid URLs
        assertTrue(UrlGenerator.isValidUrl("http://www.example.com"));
        assertTrue(UrlGenerator.isValidUrl("https://www.example.com"));
        assertTrue(UrlGenerator.isValidUrl("http://example.com"));
        assertTrue(UrlGenerator.isValidUrl("https://example.com"));
        assertTrue(UrlGenerator.isValidUrl("http://www.example.com/path"));
        assertTrue(UrlGenerator.isValidUrl("https://www.example.com/path?param=value"));
        
        // Invalid URLs
        assertFalse(UrlGenerator.isValidUrl(null));
        assertFalse(UrlGenerator.isValidUrl(""));
        assertFalse(UrlGenerator.isValidUrl("www.example.com")); // missing protocol
        assertFalse(UrlGenerator.isValidUrl("ftp://www.example.com")); // wrong protocol
        assertFalse(UrlGenerator.isValidUrl("example.com")); // missing protocol
        assertFalse(UrlGenerator.isValidUrl("not-a-url"));
        
        logger.info("URL validation test passed");
    }
    
    @Test
    @Order(6)
    @DisplayName("Should handle edge cases for custom code validation")
    void testIsValidCustomCodeEdgeCases() {
        // Edge cases
        assertFalse(UrlGenerator.isValidCustomCode("   ")); // whitespace only
        assertFalse(UrlGenerator.isValidCustomCode("a")); // single character
        assertFalse(UrlGenerator.isValidCustomCode("ab")); // two characters
        assertTrue(UrlGenerator.isValidCustomCode("abc")); // minimum valid length
        assertTrue(UrlGenerator.isValidCustomCode("a".repeat(20))); // maximum valid length
        assertFalse(UrlGenerator.isValidCustomCode("a".repeat(21))); // too long
        
        logger.info("Custom code edge case validation test passed");
    }
    
    @Test
    @Order(7)
    @DisplayName("Should handle edge cases for URL validation")
    void testIsValidUrlEdgeCases() {
        // Edge cases
        assertFalse(UrlGenerator.isValidUrl("   ")); // whitespace only
        assertFalse(UrlGenerator.isValidUrl("http://")); // incomplete URL
        assertFalse(UrlGenerator.isValidUrl("https://")); // incomplete URL
        assertTrue(UrlGenerator.isValidUrl("http://localhost"));
        assertTrue(UrlGenerator.isValidUrl("https://localhost:8080"));
        assertTrue(UrlGenerator.isValidUrl("http://127.0.0.1"));
        
        logger.info("URL edge case validation test passed");
    }
    
    @Test
    @Order(8)
    @DisplayName("Should generate consistent format for short codes")
    void testGenerateShortCodeFormat() {
        for (int i = 0; i < 100; i++) {
            String code = UrlGenerator.generateShortCode();
            
            // Check length
            assertEquals(6, code.length());
            
            // Check characters are alphanumeric
            assertTrue(code.matches("^[a-zA-Z0-9]+$"));
            
            // Check no special characters
            assertFalse(code.contains(" "));
            assertFalse(code.contains("-"));
            assertFalse(code.contains("_"));
            assertFalse(code.contains("."));
        }
        
        logger.info("Short code format consistency test passed");
    }
} 