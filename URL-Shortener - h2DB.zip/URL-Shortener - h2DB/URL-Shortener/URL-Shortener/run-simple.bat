@echo off
echo Starting URL Shortener with in-memory database...

REM Check if Java is installed
java -version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo Error: Java is not installed or not in PATH
    echo Please install Java 17 or higher from: https://adoptium.net/
    pause
    exit /b 1
)

REM Create output directory
if not exist "target\classes" mkdir "target\classes"

REM Compile Java files (without external dependencies for simple version)
javac -d "target\classes" src\main\java\com\urlshortener\*.java src\main\java\com\urlshortener\database\*.java src\main\java\com\urlshortener\server\*.java src\main\java\com\urlshortener\server\handlers\*.java src\main\java\com\urlshortener\utils\*.java

if %ERRORLEVEL% NEQ 0 (
    echo Compilation failed! Trying with dependencies...
    
    REM Try with dependencies if available
    if exist "lib\*.jar" (
        echo Compiling with dependencies...
        javac -cp "lib/*" -d "target\classes" src\main\java\com\urlshortener\*.java src\main\java\com\urlshortener\database\*.java src\main\java\com\urlshortener\server\*.java src\main\java\com\urlshortener\server\handlers\*.java src\main\java\com\urlshortener\utils\*.java
        
        if %ERRORLEVEL% NEQ 0 (
            echo Compilation failed even with dependencies!
            pause
            exit /b 1
        )
    ) else (
        echo Compilation failed and no dependencies found!
        echo Please run download-deps.ps1 first to download dependencies.
        pause
        exit /b 1
    )
)

echo Compilation successful!

REM Copy web resources
if not exist "target\classes\web" mkdir "target\classes\web"
xcopy "src\main\web\*" "target\classes\web\" /E /Y

echo Starting URL Shortener with in-memory database...
echo Access the application at: http://localhost:3331
echo Default login - Username: admin, Password: password

REM Run with dependencies if available, otherwise without
if exist "lib\*.jar" (
    java -cp "target\classes;lib/*" com.urlshortener.MainSimple
) else (
    java -cp "target\classes" com.urlshortener.MainSimple
)

pause 