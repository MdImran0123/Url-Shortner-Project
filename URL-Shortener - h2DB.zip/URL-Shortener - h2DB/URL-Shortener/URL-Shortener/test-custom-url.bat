@echo off
echo Testing Custom URL Functionality
echo ================================

echo.
echo 1. Testing custom URL creation...
curl -X POST http://localhost:3331/custom -d "url=https://www.google.com&customCode=test123&username=admin"

echo.
echo 2. Testing custom URL redirection...
echo Please visit: http://localhost:3331/test123
echo This should redirect to: https://www.google.com

echo.
echo 3. Testing with a different custom URL...
curl -X POST http://localhost:3331/custom -d "url=https://www.github.com&customCode=github&username=admin"

echo.
echo 4. Testing the new custom URL redirection...
echo Please visit: http://localhost:3331/github
echo This should redirect to: https://www.github.com

echo.
echo Test completed! Check the browser for redirections.
pause 