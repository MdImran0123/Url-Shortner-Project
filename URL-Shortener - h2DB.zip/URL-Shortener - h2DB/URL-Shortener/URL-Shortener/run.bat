@echo off
echo Building URL Shortener...

REM Create output directory
if not exist "target\classes" mkdir "target\classes"

REM Compile Java files
javac -cp "lib/*" -d "target\classes" src\main\java\com\urlshortener\*.java src\main\java\com\urlshortener\database\*.java src\main\java\com\urlshortener\server\*.java src\main\java\com\urlshortener\server\handlers\*.java src\main\java\com\urlshortener\utils\*.java

if %ERRORLEVEL% NEQ 0 (
    echo Compilation failed!
    pause
    exit /b 1
)

echo Compilation successful!

REM Copy web resources
if not exist "target\classes\web" mkdir "target\classes\web"
xcopy "src\main\web\*" "target\classes\web\" /E /Y

echo Starting URL Shortener...
java -cp "target\classes;lib/*" com.urlshortener.Main

pause 